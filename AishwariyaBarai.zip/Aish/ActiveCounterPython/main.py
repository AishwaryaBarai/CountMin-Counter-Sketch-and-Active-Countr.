import sys
import random
from math import pow

upperLimitCN  =  pow(2, 16) - 1
cn = 0
cePow  =  1

sys.stdout  =  open("ActiveCounterPython.txt","w")

for i in range(1000000):
    if (random.randint(1,sys.maxsize) % cePow) == 0:
        cn += 1
        if cn > upperLimitCN:
            cePow *= 2
            cn = cn >> 1


activeCounter =  cn * cePow
print(int(activeCounter))

sys.stdout.close()